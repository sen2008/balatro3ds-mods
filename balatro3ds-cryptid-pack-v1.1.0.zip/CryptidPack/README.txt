Cryptid Pack (3DS Port) v1.1.0
140 Jokers and 22 consumables from Cryptid (PC, by the Cryptid team),
ported to Balatro3DS: the Epic, Exotic, Candy and Cursed rarities,
the Bulwark and UltPair poker hands, and the Code and Unique
consumable types. This completes and replaces the v1.0.0 seven-Joker
first pass; those seven are unchanged.

REQUIRES THE BALATRO3DS FORK (v1.1.0)
The pack registers custom rarities, poker hands and consumable
types and creates and destroys Jokers and cards, which the stock
game's mod API cannot do. It needs the fork build and its Tier 1 +
Tier 2 mod APIs (SMODS.add_card / SMODS.destroy_joker /
SMODS.destroy_card, SMODS.Rarity, SMODS.PokerHand,
SMODS.ConsumableType):
  https://github.com/sen2008/balatro3ds-fork
On the stock Universal-Updater build the pack does not load.
The test file (test_cryptidpack.lua) stays in the mod folder; the
game ignores it.

INSTALL
1. Unzip this file.
2. Copy the CryptidPack folder to your SD card at:
     /3ds/save/Balatro3DS/sdmc/mods/CryptidPack
3. Start (or restart) Balatro3DS.
4. Check Options -> Mods: "Cryptid Pack" should be listed.
   If a mod fails to load, the reason is written to mods/mods_log.txt
   in the same folder.

WHAT'S INSIDE
- Rarities: Epic (shop weight 0.3, as on PC), Exotic (weight 0:
  never sold in the shop, exactly as on PC; Exotics arrive through
  Gateway and other creation effects), Candy (weight 3),
  Cursed (weight 3).
- Poker hands: Bulwark (five Stone cards, 100 Chips / 10 Mult,
  +50/+1 per level) and UltPair (two or more pairs in each of two
  suits, 220 Chips / 22 Mult, +40/+4 per level). Like every custom
  hand on the fork they rank below High Card in hand contests,
  because the fork's evaluator names hands by list position.
- Consumable types: Code (shop rate 1; PC rates Code at 0 because
  PC has Code booster packs, which the fork does not, so the shop
  is the only way the two ported Code cards can appear) and
  Unique (shop rate 0, as on PC).
- Cryptid's gameset system (Modest / Mainline / Madness difficulty
  overrides) is not ported; every effect uses its standard rules.

THE 140 JOKERS, BY RARITY
Common (40): 2D, :D, Adroit Joker, Blender, Blurred Joker, Bonkers Joker, Bubble M, Clicked Cookie, Crypto Coin, Cube, Cursor, Delirious Joker, Discreet Joker, Exoplanet, Fast Food M, Fidget Spinner, Foolhardy Joker, Foxy Joker, Fridge Magnet, Jolly Joker?, Kooky Joker, Loopy, M Chain, Macabre Joker, Manic Joker, Megg, Meteor Shower, Monster, Morse Code, Panopticon, Red Bloon, Sacrifice, Savvy Joker, Silly Joker, Stardust, Subtle Joker, Translucent Joker, Treacherous Joker, Tricksy Joker, Wacky Joker
Uncommon (27): AP Joker, Bonk, Bus Driver, Candy Basket, Candy Dagger, Chili Pepper, Consume-able, Cut, Eye of Hagane, Fading Joker, Key Change, Kitty Printer, Krusty the Clown, Mondrian, Monkey Dagger, Neon M, Poor Joker, Python, Reverse Card, Sapling, Scrabble Tile, Seal the Deal, The WHIP, Trick-or-Treat, Unjust Dagger, Wheel of Hope, Zooble
Rare (30): Broken Home, Chad, Compound Interest, Dropshot, Eternal Flame, Exposed, Garden of Forking Paths, High Five, Jimball, Kaleidoscope, LeBaron James, Light Up the Night, M Stack, Mask, Motebook, Nice, No Sound, No Memory, Pizza, Pizza Slice, Pot of Jokes, SUS, Tax Fraud, The Clash, The Filler, The Nuts, The Quintet, The Stronghold, The Swarm, The Unity, Weebonacci
Legendary (4): Nostalgic Invisible Joker, Thalia and Melpomeme, Waluigi, Wario
Epic (17): Boredom, Canvas, Caramel, Circus, Code Joker, Copy/Paste, Demicolon, Doodle M, Gold Joker, Huge, M, Mult Joker, Negative Joker, One for All, Sob, Virgo, m
Exotic (7): Crustulum, Duplicare, Iterum, Non Verisimile, Redeo, Speculo, Tenebris
Candy (6): Brittle Candy, Candy Buttons, Candy Cane, Cotton Candy, Mellowcreme, Wrapped Candy
Cursed (2): Monopoly Money, Rotten Egg

THE 22 CONSUMABLES
://CTRL+V (Code), Adversary (Spectral), Analog (Spectral), Asteroid Belt (Planet), Chambered (Spectral), Conduit (Spectral), Gateway (Spectral), Hertta (Planet), Kaikki (Planet), Lock (Spectral), Neutron Star (Planet), Pata (Planet), Phobos & Deimos (Planet), Planet.lua (Planet), Replica (Spectral), Risti (Planet), Ruutu (Planet), Summoning (Spectral), The Automaton (Tarot), The Blessing (Tarot), Vacuum (Spectral), White Hole (Spectral)

DEVIATIONS FROM PC
- Cube costs $0 instead of -$27: PC's joke price pays you to take
  it, but the fork requires cost >= 0, so it is free here.
- Wee Fib's art is the vanilla Fibonacci sprite: PC gives it no
  atlas of its own (the joke is that it is a tiny Fibonacci), and
  its PC display size of 0.7 has no fork equivalent.
- Virgo's floating soul layer uses the glyph cell of its atlas:
  PC's soul_pos points outside the atlas grid, so on PC that
  layer renders nothing there either.
- Kitty Printer keeps its X2 Mult; the Cat Tag conversion is
  dropped (Cryptid's custom tags cannot be registered).
- Adversary drops its shop-price doubling (the fork has no
  shop-price modifier API), so the port is strictly stronger
  than PC's version.
- ://CTRL+V copies playing cards only; PC's consumable and
  booster-pack target branches have no fork equivalent.
- Conduit converts playing cards only; fork consumables cannot
  select Jokers as targets.
- Kaikki levels Bulwark and UltPair only; PC's third hand,
  Clusterfuck, cannot be registered.
- Morse Code grows on editioned Joker sales only (the fork's
  selling context covers Jokers, not consumables).
- Exposed and Mask keep their retrigger halves; their debuff
  halves need a debuff_card context the fork never raises.
- Clicked Cookie keeps its Chips; the per-click decay needs
  Cryptid's cry_press context.
- LeBaron James keeps its dynamic hand size; the held-in-hand
  scoring half needs an SMODS.score_card hook.
- Seal the Deal's random seal pool is the four vanilla seals;
  PC's pool adds Cryptid's Green and Azure seals, which cannot
  be registered.
- Monopoly Money destroys bought Jokers and consumables;
  voucher and booster purchases cannot be matched to an offer.
- Code Joker drops PC's unlock gate (discover every Code card).
- The M-edition creations (Jolly Joker?, Scrabble Tile) create
  plain Jokers; the fork has no M edition.
- One for All drops its booster-slot, shop-size and voucher-slot
  increases; the fork has no config fields for them.
- Demicolon's forcetrigger is expressed through the fork's
  retrigger_joker return on its right neighbour in joker_main.
- Canvas drops the gameset modest cap (no gamesets, see above).

NOT PORTED: TALISMAN BIG NUMBERS (14 JOKERS)
These effects return or scale Talisman-only values (e_mult,
e_chips and friends: Mult or Chips raised to a power). Lua
numbers in this engine cannot represent them and capping them
would fake the effect, so they stay out entirely.
- Circulus Pistoris: returns echips and emult (^pi Chips and ^pi Mult at exactly 3 hands remaining) — Talisman-only return types
- Exponentia: returns emult (^Mult, gains ^0.03 whenever XMult is triggered) — Talisman-only return type the fork cannot express
- Facile: returns emult (^3 Mult) — Talisman-only return type the fork cannot express
- Formidiulosus: returns emult (1 + 0.01 per Candy Joker held) — Talisman-only return type; it also creates random cry_candy-rarity Jokers, which the fork's key-based SMODS.add_card cannot do
- Googol Play Card: config.extra.Xmult = 1e100 (a googol) - at/past the ~1e100 Talisman-scale threshold; its unlock also requires scoring 1e100 chips in one hand
- Happy House: returns emult (Mult ^ 4) after 114 hands played — Talisman-only exponent return type the fork cannot express
- Jimbo-tron 9000: returns emult (^Mult = 1 + 1 per default Joker held) - Talisman-only return type the fork cannot express
- Night: returns emult = 3 (Mult ^ 3) on the final hand of the round - Talisman-only return type
- Primus: returns emult (^Mult, starts at ^1.01 and gains ^0.17 per all-prime hand) — Talisman-only return type the fork cannot express
- Starfruit: returns emult (^Mult, starting at ^2 and decaying per shop reroll) - Talisman-only return type the fork cannot express
- Stella Mortis: gains and returns emult (+^0.4 Mult per Planet card destroyed at end of shop) — Talisman-only return type; the Planet destruction alone does not carry the effect
- The Complete and Utter Annihilation of Everything That Makes Balatro Sacred: returns emult = 5.2 (Mult ^ 5.2) - Talisman-only return type; also requires the cry_WholeDeck hand
- Tredecim: returns emult (^Mult) in its other_joker branch - Talisman-only return type the fork cannot express; also spawns random M-pool Jokers via create_card("M")
- Universe: Returns e_mult (^1.2 Mult) for Astral cards - Talisman-only return type; also requires the cry_astral edition, which cannot exist in the fork

NOT PORTED: OTHER MISSING SYSTEMS (125)
- ...Like Antennas to Heaven: Scales and returns x_chips (Xchips) — fork calculate returns support chips/mult/xmult/dollars only; no x_chips return exists
- ://ALTTAB: creates vanilla tag only — pending central decision
- ://ASSEMBLE: Adds base Mult to the hand formed by the highlighted cards via SMODS.upgrade_poker_hands with a custom function (+1 per owned Joker). The fork has no upgrade_poker_hands, and cannot identify the poker hand of an arbitrary highlighted subset (PC uses G.FUNCS.get_poker_hand_info and G.GAME.hands, incl. the cry_None hand).
- ://CLASS: Chosen-enhancement conversion runs through Cryptid's overlay menu plus init hooks on Card:click and CardArea:emplace, and the choice list includes custom enhancements m_cry_echo, m_cry_light and m_cry_abstract. No menu or method-hook API in the fork (mod_conv only covers one fixed vanilla enhancement).
- ://COMMIT: Targets a highlighted Joker via Cryptid.get_highlighted_cards over G.jokers (fork consumable selection is hand cards only) and creates a random Joker of the same rarity via create_card('Joker', legendary, rarity, ...). No random-by-rarity Joker creation API in the fork.
- ://CRASH: Effect is to crash or freeze the game: use() runs a random crashes[] function that overrides love.errorhandler/love.draw, fills the screen with Crash cards, or opens a text box whose contents are run via loadstring(G.ENTERED_ACE) (arbitrary code execution). No fork equivalent; deliberately destructive.
- ://DECLARE: Creates a brand-new poker hand at runtime from the highlighted cards with a player-typed name (text-input UIBox, Cryptid.create_declare_hand mutating G.GAME.hands, plus localize and SMODS.is_poker_hand_visible hooks). Fork poker hands register only at load and there is no text-input UI.
- ://DELETE: Banish system: writes G.GAME.cry_banished_keys and G.GAME.cry_banned_pcards so the selected shop item (and rank+suit, for playing cards) never appears again this run. No banish/pool-exclusion state in the fork, and its targets are highlighted shop items, which the fork cannot select.
- ://DIVIDE: Halves current shop prices by writing misprint_cost_fac on every card in G.shop_jokers, G.shop_booster and G.shop_vouchers and calling set_cost(). The fork exposes no shop areas or price-modification API.
- ://EXPLOIT: Opens Cryptid's exploit overlay menu (G.FUNCS.overlay_menu / G.UIDEF.exploit_menu) to make the next hand calculate as a chosen visible hand and grant temporary Ascension Power (cry_asc_num, G.GAME.sunnumber). No menu/UI API and no ascension system in the fork.
- ://GLOBAL: Applies Cryptid's cry_global sticker to a selected playing card (the card counts as all suits/ranks via Cryptid hooks). Custom stickers do not exist in the fork.
- ://INSTANTIATE: Draws specific existing deck cards (first matching the selected card's rank, then first matching its suit) into hand via draw_card(G.deck, G.hand, ...). The fork exposes deck contents only as raw card_data and has no move-card-from-deck-to-hand API.
- ://KEYGEN: Creates and redeems a random Voucher (create_card('Voucher') + card:redeem(), perishable/banana/keygen stickers) and dissolves previously keygen-created vouchers, preserving G.GAME.current_round.voucher. Creating/redeeming a voucher as an effect is blocked and there is no G.GAME.
- ://LOG: Whole effect is a custom UIBox readout menu predicting future RNG: next Boss/Voucher via an init hook on SMODS.get_next_vouchers and saved G.GAME.pseudorandom state, the next 5 shop Jokers, or the top 10 deck cards. No UIBox or RNG-state API in the fork.
- ://MACHINECODE: Creates a random consumable that must carry the cry_glitched edition (card:set_edition({cry_glitched = true})); its scrambled DynaText name rendering also needs Cryptid.randomchar/UI objects. Custom editions cannot be created in the fork.
- ://MALWARE: Sets the Cryptid glitched edition on every card held in hand (CARD:set_edition({cry_glitched = true})). Custom editions cannot be created or detected in the fork.
- ://MERGE: Merges a consumable into a playing card: CARD:set_ability(G.P_CENTERS[<consumable key>]) inside temporary CardAreas (the CCD system), turning the playing card into that consumable's centre. Playing cards cannot change centre/set in the fork, and there is no event manager.
- ://MULTIPLY: Doubles all values of a selected Joker via Cryptid.manipulate (Cryptid's generic value-manipulation library) and restores them through an init hook on end_round. No value-manipulation API and no method hooks in the fork; also needs highlighted-Joker targeting.
- ://NPERROR: Returns the last played hand to hand by matching Cryptid-tracked G.GAME.last_hand_played_cards sort_ids in discard/deck and moving them with draw_card(). No last-hand tracking and no move-card-to-hand API in the fork.
- ://OFFBYONE: Effect is Cryptid booster state G.GAME.cry_oboe: the next Booster Pack gets +# extra cards and +# extra choices. Boosters cannot be created or modified in the fork and there is no G.GAME.
- ://PATCH: Core lasting effect is permanent debuff immunity via the Cryptid flag cry_debuff_immune, read by Cryptid debuff hooks; the fork raises no debuff contexts. It also iterates G.jokers.cards and G.consumeables.cards, which do not exist in the fork.
- ://PAYLOAD: Effect is Cryptid library state G.GAME.cry_payload: a multiplier on the next defeated Blind's interest payout, maintained and paid out by Cryptid hooks. No G.GAME and no interest system in the fork.
- ://QUANTIFY: Transfers a selected card or Booster into the Joker tray as a functioning Joker via init hooks overriding Card:calculate_joker and Blind:debuff_hand, using SMODS.calculate_individual_effect / SMODS.calculate_effect. None of those exist in the fork, and it targets cards in any area (G.I.CARD scan).
- ://REBOOT: Round-state reset: G.FUNCS.draw_from_hand_to_discard / draw_from_discard_to_deck, ease_discard and ease_hands_played computed from G.GAME.round_resets and G.GAME.current_round, then a deck shuffle and G.STATE change via the event manager. No round-state manipulation API in the fork.
- ://REVERT: Rewinds the run to the start of the Ante: an init hook overrides save_run to snapshot state with STR_PACK into G.GAME.cry_revert, and use() calls G:delete_run() / G:start_run({savetext}). No save-state or run-restart API in the fork.
- ://REWORK: Creates Cryptid tag tag_cry_rework (Tag('tag_cry_rework') + add_tag) holding the destroyed Joker's key and next Collection-order edition. Cryptid tags cannot be registered in the fork.
- ://RUN: Visits a shop mid-Blind: stashes the hand in a temporary CardArea, forces G.STATE = G.STATES.SHOP, and restores via init hooks on G.FUNCS.toggle_shop, Game:update_shop and G.UIDEF.shop. No game-state, CardArea or shop-forcing API in the fork.
- ://SEED: Applies Cryptid's cry_rigged sticker to a selected Joker, playing card or consumable so all of its probability rolls succeed (Cryptid probability hooks read ability.cry_rigged). Custom stickers do not exist in the fork.
- ://SPAGHETTI: Creates a random Food-pool Joker with the cry_glitched edition (create_card('Food', ...) + set_edition). Custom editions cannot be created, and the fork has no Food pool or random-Joker-by-pool creation API.
- ://UPDATE: Placeholder with no effect in the PC source: can_use always returns false and use/bulk_use are commented out ('To Be Determined in a future update'). There is nothing to port.
- ://VARIABLE: Chosen-rank conversion runs through Cryptid's overlay menu plus init hooks on Card:click and CardArea:emplace calling SMODS.change_base. The fork raises no change_rank/change_suit and has no menu or method-hook API.
- ;//: Ends the current non-Boss Blind without cashing out by setting G.GAME.current_round.semicolon and forcing G.STATE = G.STATES.HAND_PLAYED with end_round() via the event manager. No blind-ending or game-state API in the fork.
- ABC: debug/test item in PC source, not player content
- Ace Aequilibrium: creates Jokers in Collection order using the shared G.GAME.aequilibriumkey sequence over the whole Joker pool; fork has no collection-ordered pool API and no G.GAME (random creation would change the effect)
- Allmighty Center Checker: debug/test item in PC source, not player content
- Arsonist: Requires the destroying_card/destroy_card context, which the fork does not raise
- Astral in a Bottle: On-sell effect applies the cry_astral edition to a random Joker; Cryptid editions cannot be created in the fork
- Big Cube: Returns xchips (X6 Chips) — fork calculate returns support chips/mult/xmult/dollars only; no x_chips return exists
- Blacklist: sets the hand's Chips and Mult totals to 0 by writing the hand_chips/mult globals; fork calculate returns only add/multiply and cannot override the running totals
- Bonus Joker: permanently increases Joker/Consumable area size via G.jokers:change_size and G.consumeables:change_size - fork slot modifiers are static and only apply while held; no permanent-change API
- Booster Joker: Effect is SMODS.change_booster_limit in add/remove_from_deck (+1 Booster Pack shop slot) — the fork has no booster-slot modifier or equivalent
- Broken Sync Catalyst: Returns cry_broken_swap (swap 10% of Chips with 10% of Mult mid-scoring), a Cryptid scoring hook with no fork return or context equivalent
- Buttercup: requires a custom cry_storage CardArea with drag UI for stashing shop items plus G.GAME.next_shop_cards shop injection; neither exists in the fork
- Caeruleum: works entirely through an init hook on SMODS.calculate_individual_effect that promotes adjacent Jokers' chip operators (+ to X to ^); fork has no calculate-effect hook and the ^ tier is Talisman-only
- Candy Sticks: requires disabling the Boss Blind and restoring it later from a saved blind (blind:disable()/blind:load()); the fork has no blind disable/restore API and does not raise blind_disabled
- Carved Pumpkin: Disables Boss Blind abilities via G.GAME.blind:disable(); the fork has no blind-disable API (blind_disabled is not raised or supported)
- Cat Owl: Requires the check_enhancement context, which the fork does not raise, and the m_cry_echo custom enhancement, which cannot exist in the fork
- Celestial Globe: Scales and returns x_chips (Xchips) — fork calculate returns support chips/mult/xmult/dollars only; no x_chips return exists
- Chocolate Die: requires SMODS.Events ev_cry_choco0..10 (Cryptid event system); those events apply the cry_flickering sticker and other global hooks - no event or sticker system in the fork
- Clockwork Joker: requires setting a played card's enhancement to m_steel mid-hand (context.full_hand[1]:set_ability) and copy_card self-duplication when its four counters align - neither API exists in the fork
- Digital Hallucinations: The fork's open_booster context carries no booster card or pack type (the event is emitted with an empty table), so the pack-type-dependent Negative creation cannot be implemented
- Double Scale: whole effect is context.scaling_card plus override_scalar_value (interception of SMODS.scale_card) - that context is not raised and the fork has no scale-card system
- ERROR: on sell it duplicates every other held Joker via copy_card (exact copies incl. ability state) using G.jokers.cards, and its tooltip needs Cryptid.predict_card_for_shop - no fork copy API or G.jokers.cards
- Effarcire: draws the whole deck to hand via SMODS.draw_cards queued through G.E_MANAGER with G.GAME.effarcire_buffer state; fork has no draw-to-hand API, no event manager and no G.GAME
- Emergency Chips: On-sell effect writes the current hand score (G.GAME.chips) and forces G.STATE to HAND_PLAYED; the fork exposes no current-score access or game-state control (no G.GAME)
- Energia: duplicates acquired Tags with a scaling copy count; creating tags from Joker code is not a listed API (Cryptid's own tags cannot be created at all; vanilla tags only via the undocumented Game:addTag) — pending central decision on tag creation
- FUNCTION://: Depends on Cryptid program state G.GAME.cry_function_cards / cry_last_used_consumeables (the last three consumables used, tracked by Cryptid hooks) and applies the cry_function sticker to the created copy. Neither the tracking state nor custom stickers exist in the fork.
- Familiar Currency: Creates a random Meme-pool Joker via SMODS.add_card({set = 'Meme'}); Meme is a Cryptid ObjectType pool with no fork set or pool equivalent
- Flesh Panopticon: multiplies the Boss Blind target via G.GAME.blind.chips at setting_blind - no G.GAME and no blind-target modification API in the fork
- Fractal Fingers: Effect is +2 card selection limit via SMODS.change_play_limit/change_discard_limit; the fork has no play/discard selection-limit modifier (h_size is hand size, not selection limit)
- Fucked-Up Joker: effect requires the cry_Clusterfuck poker hand (8+ played cards forming no pair/flush/straight); the fork evaluates hands on a normal play and Clusterfuck is not registerable
- Gemini: doubles all values of the leftmost Joker via Cryptid.manipulate, Cryptid's value-manipulation library; fork has no API to rewrite another Joker's ability values
- Ghost: possession is the cry_possessed sticker plus a Cryptid calculate hook that inverts the possessed Joker's effects; stickers and effect-inversion hooks do not exist in the fork
- HOOK://: Applies Cryptid's cry_hooked sticker linking 2 selected Jokers so each force-triggers the other (force-trigger/demicolon system), installed via an init hook overriding Card:start_dissolve. No stickers, no force-trigger context and no method hooks in the fork; also needs highlighted-Joker targeting.
- Hammerspace: Requires Cryptid's CCD system: Cryptid.random_consumable(..., true) returns a consumable-as-enhancement center that is applied to playing cards as their ability; the fork has no consumable-as-enhancement (CCD) mechanic
- Hunting Season: Requires the destroy_card context (context.destroy_card == middle card of the played hand), which the fork does not raise
- Instability: mod_conv to the custom Abstract enhancement (m_cry_abstract); custom enhancements cannot be created in the fork and mod_conv only accepts the 8 vanilla enhancements
- Jawbreaker: requires Cryptid.manipulate (misprintize) to double every numeric value of the adjacent Jokers; fork Jokers do not expose their values in a writable per-copy table (vanilla effects are hardcoded)
- Kidnapping: Requires G.GAME.jokers_sold (run-wide history of sold Jokers); the fork has no G.GAME and no sold-Joker history in its listed live game access
- Labyrinth: No calculate/config: effect lives in lib/overrides.lua hooks on G.FUNCS.play_cards_from_highlighted/discard_cards_from_highlighted that zero G.GAME.current_round.hands_played/discards_used — the fork exposes no hook to reset its round counters
- Lucky Joker: PC fires on other_card.lucky_trigger during individual scoring; the fork never exposes lucky_trigger to mod calculate (its lucky rolls surface only as probability_success, which reads repetitions and cannot pay dollars)
- Many Have Lost Their Minds Comprehending This Joker: effect requires the cry_WholeDeck poker hand (the entire 52-card deck in one play; the hand's own stats are bignum-scale) - not registerable in the fork
- Maximized: No calculate at all: effect is an init hook overriding Card:get_id (all faces=Kings, numbered=10s) plus a G.UIDEF.view_deck override — Lovely/global-hook territory, no fork equivalent
- Meld: Applies the Cryptid Double-Sided edition (e_cry_double_sided); editions beyond foil/holo/polychrome/negative cannot be created in the fork, and it also requires selecting a Joker, which fork consumables cannot do
- Membership Card: Requires Cryptid.member_count (live Cryptid Discord member count fetched over HTTPS by the Cryptid library); no such data source exists in the fork
- Nebulous Joker: effect requires the cry_None poker hand (a hand containing 0 cards); a 0-card play cannot be made or scored in the fork and None is not a registerable hand
- Necromancer: Requires G.GAME.jokers_sold (run-wide history of sold Jokers) to resurrect a random one; the fork has no G.GAME and no sold-Joker history
- Nibiru: Levels cry_None, Cryptid's no-hand-played pseudo-hand; the fork has no equivalent hand to register or level (its stats are derived from bignum hand state)
- Nostalgic Candy: selling it permanently gains hand size via G.hand:change_size - fork h_size modifiers only apply while a Joker is held; no permanent hand-size API
- Nostalgic Googol Play Card: sell effect creates 2 copies of the leftmost Joker via copy_card (exact duplicate incl. ability state and edition) - the fork has no copy API; SMODS.add_card only creates fresh instances
- Number Blocks: its target rank is G.GAME.current_round.cry_nb_card, state chosen by a Cryptid override tied to The Castle - no G.GAME and no such round state in the fork
- Oil Lamp: Requires Cryptid.manipulate (library value-multiplication of the Joker to the right); no fork equivalent
- Old Blueprint: core effect is SMODS.blueprint_effect (copies the Joker to the right), which has no fork equivalent; its calculate and loc_vars also read G.jokers.cards
- Old Membership Card: effect scales with Cryptid.member_count, the live Cryptid Discord member count fetched over HTTPS - Cryptid library state with no fork equivalent
- On the Flip Side: Requires the cry_double_sided edition (e_cry_double_sided) on other Jokers; Cryptid editions cannot be created or detected in the fork
- POINTER://: Opens Cryptid's collection overlay to create an arbitrary chosen card (G.GAME.USING_POINTER state, overlay_menu UI, a Card:click hook, pointer_create_card); the fork has no overlay-menu or click-hook API for mods
- Paved Joker: Effect lives entirely in poker-hand evaluation (Stone cards fill gaps of 1 in Straights and Flushes) via evaluate_poker_hand hooks; the Joker has no calculate and the fork does not raise evaluate_poker_hand
- Penetrating Joker: effect requires the cry_Clusterfuck poker hand (8+ played cards forming no pair/flush/straight); the fork evaluates hands on a normal play and Clusterfuck is not registerable
- Perkele: Levels cry_None and cry_WholeDeck (hands that cannot be registered in the fork) plus cry_asc_hands via Cryptid's Ascension system; its WholeDeck Observatory branch also returns emult
- Pickle: Creates random Tags via get_next_tag_key/add_tag on skip_blind — the fork has no tag-creation API and the PC tag pool includes Cryptid tags, which cannot be registered at all
- Pirate Dagger: Scales and returns x_chips (Xchips) — fork calculate returns support chips/mult/xmult/dollars only; no x_chips return exists
- Pity Prize: Effect creates a Tag chosen from the full tag pool via Cryptid.get_next_tag/get_next_tag_key, which includes Cryptid tags; Cryptid tags cannot be registered in the fork
- Potion: Its entire use() is gated on Cryptid's Chocolate Die event state (G.GAME.events.ev_cry_choco3) and applies that event's maluses; the event system does not exist in the fork, nothing can grant the card (in_pool is false on PC), and its set (Unique) is not the blocker
- Project Sundial: its payoff is Cryptid's global xblindsize hook (blind size reduced 85% for the rest of the run, lib/calculate.lua) driven by G.GAME.sundial state - no G.GAME and no blind-size API in the fork
- Pumpkin: Requires context.game_over with a saved=true death-prevention return and the joker_type_destroyed transformation context; neither is raised or supported in the fork
- Queen's Gambit: Requires context.destroying_card (scored Queen destroyed during a Royal Flush) — destroying_card is not raised by the fork
- RNJoker: abilities are generated and interpreted by Cryptid.rnjoker_randomize / its calculate interpreter, which uses G.GAME.joker_buffer and consumeable_buffer, G.jokers.cards, the other_joker and debuffed_hand contexts, and x_chips/payout returns - no fork equivalent
- Rescribere: monkey-patches every other held Joker's calculate_joker function to append a sold Joker's effects; fork Jokers carry no per-instance calculate_joker to patch
- Ritual: Applies Cryptid editions e_cry_mosaic or e_cry_astral (2 of its 3 outcomes); editions beyond foil/holo/polychrome/negative cannot be created in the fork
- Scalae: sole effect is in the Cryptid-specific scaling_card context, rewriting other Jokers' scaling increments as degree-N polynomials through SMODS.scale_card internals; fork never raises scaling_card and exposes no scaling hook
- Sock and Sock: Requires detecting the m_cry_abstract custom enhancement on played cards; Cryptid enhancements cannot exist in the fork
- Sol: Requires Cryptid's Ascension system (Cryptid.asc_level_up, G.GAME.sunlevel/sunnumber, cry_asc_num ascension power, gated on G.GAME.cry_asc_played); no ascension state or ascended hands exist in the fork
- Source: Applies the custom cry_green seal: config.mod_conv = 'cry_green_seal' and use() calls highlighted:set_seal('cry_green'). Custom seals cannot be created in the fork (mod_conv covers vanilla enhancements only, and seals are not enhancements).
- Spectrogram: counts scored Echo Cards, the custom enhancement m_cry_echo - custom enhancements cannot be created or detected in the fork
- Spy: disguise requires update()/generate_ui hooks that swap sprite, rarity and cost to a random secret Joker and spoof its description, plus the perishable sticker; no fork equivalent
- Supercell: returns xchips (XChips) in joker_main - the fork return table has no xchips field (MODDING.md; no sibling pack uses one)
- Sync Catalyst: returns balance = true (balances Chips and Mult, Plasma-style) - the fork return table has no balance field
- Test Joker: debug/test item in PC source, not player content
- The: effect requires the cry_None poker hand (a hand containing 0 cards); a 0-card play cannot be made or scored in the fork and None is not a registerable hand
- The Eclipse: mod_conv to the custom Echo enhancement (m_cry_echo); custom enhancements cannot be created in the fork and mod_conv only accepts the 8 vanilla enhancements
- The Fuck!?: effect requires the cry_Clusterfuck poker hand (8+ played cards forming no pair/flush/straight); the fork evaluates hands on a normal play and Clusterfuck is not registerable
- The Seraph: mod_conv to the custom Light enhancement (m_cry_light); custom enhancements cannot be created in the fork and mod_conv only accepts the 8 vanilla enhancements
- The Universe In Its Fucking Entirety: Levels cry_WholeDeck, which cannot be registered in the fork (the hand needs whole-deck bignum stats); its Observatory calculate also returns emult, a Talisman-only return type
- Tiny: creates the Cryptid tag tag_cry_double_m (Double M); Cryptid tags cannot be registered in the fork
- Trade: Requires un-redeeming an owned voucher and redeeming two new ones; the fork has no voucher unredeem/redeem API for mods (owned vouchers are only the G.vouchers id list, redeem() runs at purchase only)
- Tropical Smoothie: Requires Cryptid.manipulate (library value-multiplication of every other Joker's ability values); no fork equivalent
- Typhoon: Applies the custom Azure seal (cry_azure_seal / set_seal 'cry_azure'); custom seals cannot be created in the fork
- Undefined Joker: effect requires the cry_None poker hand (a hand containing 0 cards); a 0-card play cannot be made or scored in the fork and None is not a registerable hand
- Universum: sole context is cry_universum, fired by Cryptid's SMODS.upgrade_poker_hands override to multiply hand level-up gains (X2 chips/mult per level); fork raises no level-up context and has no hand-level modification hook
- Void: Levels cry_Clusterfuck, which cannot be registered in the fork (the hand needs more than 5 played cards); there is no hand for its hand_type to level
- Voxel: Levels cry_Declare0/1/2, the custom poker hands created at runtime by the Code card Declare (code-card program state); no Declare hands can exist in the fork
- Wonka Bar: requires SMODS.change_play_limit / SMODS.change_discard_limit; the fork has no play or discard selection-limit system or modifier
- Words Can’t Even Begin to Describe This Joker: effect requires the cry_WholeDeck poker hand (the entire 52-card deck in one play; the hand's own stats are bignum-scale) - not registerable in the fork
- Yarn Ball: Requires the level of a held Cat Tag (tag_cry_cat); Cryptid tags cannot be registered in the fork and G.GAME.tags is unavailable
- function dump man B): debug/test item in PC source, not player content

LICENSE AND CREDITS
Cryptid is GPLv3; this port is GPLv3 too, and the full license
text ships in this folder (LICENSE). Original mod by the Cryptid
team (SpectralPack): https://github.com/SpectralPack/Cryptid
Sprites are cropped from the PC mod's own atlases.
