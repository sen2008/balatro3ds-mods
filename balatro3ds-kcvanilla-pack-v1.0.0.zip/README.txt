KCVanilla Pack (3DS Port) v1.0.0
Nine Jokers from KCVanilla (PC, by krackocloud) ported to Balatro3DS.
(Swiss Cheese is a separate download: KCVanillaSwiss.)

INSTALL
1. Unzip this file.
2. Copy the KCVanillaPack folder to your SD card at:
     /3ds/save/Balatro3DS/sdmc/mods/KCVanillaPack
3. Start (or restart) Balatro3DS.
4. Check Options -> Mods: "KCVanilla Pack (3DS Port)" should be listed.
   If a mod fails to load, the reason is written to mods/mods_log.txt
   in the same folder.

INCLUDED JOKERS
- Composition (Common, $4): +4 Mult per Joker to the left, +20 Chips per Joker to the right.
- Royal Guard (Common, $5): if the played hand has no Kings or Queens, +10 Chips per King/Queen in your full deck.
- Joker-chan (Uncommon, $6): at end of round, gains +2 Mult per Common Joker held.
- Red Envelope (Uncommon, $5): earn $8 per Common Joker when the Boss Blind is defeated.
- Jimbot (Uncommon, $5): gains the Chip value of the first scoring numbered card each round.
- Ten-Pin (Uncommon, $5): a scoring 10 gives X2 Mult for the next 2 hands.
- Handy Joker (Uncommon, $6): gains X1 Mult per single enhanced card discarded; resets after the Boss Blind.
- Joker Energy (Uncommon, $6): scored Wild cards give a random one of +10 Mult, +100 Chips, X2 Mult, $5.
- Power Grid (Uncommon, $6): scored Mult cards give X Mult, growing +0.1 per Mult card scored this round.

Validated headlessly against the Balatro3DS source (loader + per-Joker
scoring tests, 13/13) on 2026-10-20. Not yet tested on real hardware.

Original mod: https://github.com/kcgidw/kcvanilla
Game: https://github.com/idkhan/Balatro3DS
