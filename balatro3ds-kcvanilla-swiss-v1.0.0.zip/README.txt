KCVanilla: Swiss Cheese -- Balatro3DS port
============================================

The Joker: Swiss Cheese (Rare, $8)
  X1 Mult for each gap of 1 rank between the ranks in the played poker hand.
  (ex: 2 and 4 with no 3 = one gap = X2 total. 2, 4, 6 = two gaps = X3.)

Original PC mod: "Swiss Cheese" from KCVanilla by krackocloud
  https://github.com/kcgidw/kcvanilla
Ported to Balatro3DS (the Universal-Updater version, idkhan/Balatro3DS)
  because that port loads Steamodded-style mods. Effect code is the
  original, unchanged; only the packaging changed (see the .lua header).

INSTALL
-------
1. Unzip this file.
2. Copy the whole "KCVanillaSwiss" folder to your 3DS SD card at:

     /3ds/save/Balatro3DS/sdmc/mods/KCVanillaSwiss

   (The game creates the mods folder the first time it starts. The full
   path on the card is 3ds/save/Balatro3DS/sdmc/mods/ -- inside it you
   should see KCVanillaSwiss/KCVanillaSwiss.json etc.)
3. Start Balatro3DS. Check Options -> Mods: "KCVanilla: Swiss Cheese
   (3DS Port)" should show as loaded.
4. Swiss Cheese is Rare, so it shows up in the shop like any Rare Joker
   (and it's already discovered/unlocked).

If it does not load, the game writes why to mods/mods_log.txt in the
same mods folder.

NOTES
-----
- Needs Balatro3DS v2.0.x (the -base releases on Universal-Updater).
- A saved run remembers its mods; removing this mod mid-run makes
  Continue ask you to reinstall it. The run itself is kept.
- Includes Negative art (pre-made .t3x, since the 3DS cannot run the
  PC shader). Without it a Negative copy would use the normal art.
- Files: KCVanillaSwiss.json (manifest), KCVanillaSwiss.lua (the Joker),
  assets/1x/swiss.png + swiss.t3x, swiss_negative.png + .t3x.
  The .png files are only for desktop testing; the 3DS loads the .t3x.
